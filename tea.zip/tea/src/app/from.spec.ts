import { From } from './from';

describe('From', () => {
  it('should create an instance', () => {
    expect(new From()).toBeTruthy();
  });
});

export class From {
    drinks: Array<string>;
    cuptypes: Array<string>;
    sweets: Array<string>;
    temperatures: Array<string>;
    ingredients: Array<string>;
}
